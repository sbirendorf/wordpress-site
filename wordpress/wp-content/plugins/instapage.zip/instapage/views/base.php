<div class="l-wrapper">
  <div class="ui-section">
    <div id="instapage-container" class="ui-sub-section instapage-cms-plugin">
      <div class="l-group__item page-loader">
        <span class="c-loader c-loader--x-large"></span>
      </div>
    </div>
  </div>
</div>
