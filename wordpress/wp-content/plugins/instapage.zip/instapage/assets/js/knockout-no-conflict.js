/* globals ko */
var instapageKO = ko;
window.instapageKO = instapageKO;
